package sample;

public enum MoveType {
    None, Normal, Kill
}
